/**
	 * author: Dishant Tekwani
 */
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Forwarder2ToDserver extends PacketContent {

    String name;
    String content;

    Forwarder2ToDserver(String name, String content) {
        type= FWD2_TO_DEST;
        this.name = name;
        this.content = content;
    }

    protected Forwarder2ToDserver(ObjectInputStream oin) {
        try {
            type= FWD2_TO_DEST;
            //dstNode= oin.readUTF();
            name= oin.readUTF();
            content=oin.readUTF();
        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            //oout.writeUTF(dstNode);
            oout.writeUTF(name);
            oout.writeUTF(content);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "Content:" + content;
    }

    public String getContent()
    {
        return "Content:" + name;
    }

    public String getName() {return "Name:" + name; }

    public String getPacketInfo() {
        return content;
    }
}
