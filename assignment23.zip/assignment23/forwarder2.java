/**
	 * author: Dishant Tekwani
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.HashMap;

public class forwarder2 extends Node {
    static final int DEFAULT_SRC_PORT = 54321;
    static final int DESTINATION_SERVER_PORT = 54321;
    static final String ADDRESS_DESTINATION_SERVER = "172.10.0.3";
    InetSocketAddress dstAddress;
    InetSocketAddress dstdserverAddress;
    InetSocketAddress dstcontrollerAddress;
    String destinationOfPacket = "dserver";

    HashMap<String, String> forwardingTable;

    forwarder2(String dstforwarder3Host, int dstforwarder3Port, int srcforwarder2Port) {
        try {
                socket= new DatagramSocket(srcforwarder2Port);
                listener.go();

            forwardingTable = new HashMap<String, String>();
        }
        catch(java.lang.Exception e) {e.printStackTrace();}
    }

    public void onReceipt(DatagramPacket packet) {
        try {
            System.out.println("Received packet");

            PacketContent content= PacketContent.fromDatagramPacket(packet);

            if (content.getType()==PacketContent.FWD3_TO_FWD2)
            {
                if (forwardingTable.get(((Forwarder3ToForwarder2) content).getName()) == null) {

                    System.out.println("Scanning for destination of packet ...");
                    forwardingTable.put(destinationOfPacket, ((Forwarder3ToForwarder2) content).getName());
                    System.out.println("Added: " + destinationOfPacket + ", Next destination: " + forwardingTable.get(destinationOfPacket));


                    String containerOfDestinationNode = forwardingTable.get(destinationOfPacket);
                    Forwarder2ToDserver packetFordserver;
                    packetFordserver = new Forwarder2ToDserver(destinationOfPacket, "hello world");
                    System.out.println("Sending packet to next destination: " + containerOfDestinationNode);
                    dstdserverAddress = new InetSocketAddress(destinationOfPacket, 54321);
                    DatagramPacket packetSentToDestination = packetFordserver.toDatagramPacket();
                    packetSentToDestination.setSocketAddress(dstdserverAddress);
                    socket.send(packetSentToDestination);
                }
            }
        }
        catch(Exception e) {e.printStackTrace();}
    }


    public synchronized void start() throws Exception {
        System.out.println("Waiting for contact");
        this.wait();
    }


    public static void main(String[] args) {
        try {
            (new forwarder2(ADDRESS_DESTINATION_SERVER, DESTINATION_SERVER_PORT, DEFAULT_SRC_PORT)).start();
            System.out.println("Program completed");
        } catch(java.lang.Exception e) {e.printStackTrace();}
    }
}
