/**
	 * author: Dishant Tekwani
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.io.IOException;

public class forwarder3 extends Node {
	static final int DEFAULT_SRC_PORT = 54321;
	static final int CONTROLLER_PORT = 54321;

	InetSocketAddress dstcontrollerAddress;
	InetSocketAddress dstforwarder2Address;
	InetSocketAddress dstcslaptopAddress;
	String cslaptopAddress = "cslaptopn1";

	DatagramPacket packetSentFromLaptop;
	String forwarder2Address = "forwardern2";
	String packetDestinationAddress = "dserver";

	HashMap<String, String> forwardingTable;

	forwarder3( int srcforwarder3Port) {
		try {

			  dstcontrollerAddress = new InetSocketAddress("controller", 54321);
				dstcslaptopAddress = new InetSocketAddress("cslaptopn1", 54321);
				socket= new DatagramSocket(srcforwarder3Port);
				listener.go();

			 forwardingTable = new HashMap<String, String>();
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	public void onReceipt(DatagramPacket packet) {
		try {
			System.out.println("Received packet");

			ForwarderToController initialcontrollerPacket = new ForwarderToController("forwardern3");
			DatagramPacket packetFwdTocontroller = initialcontrollerPacket.toDatagramPacket();
			packetFwdTocontroller.setSocketAddress(dstcontrollerAddress);
			System.out.println("Sending packet to controller to see it is online...");
			socket.send(packetFwdTocontroller);

			PacketContent content= PacketContent.fromDatagramPacket(packet);
			System.out.println(content.getType());
			if (content.getType()==PacketContent.TO_UPDATE_TABLE) {
				System.out.println("Adding new container to forwarding table");
				System.out.println("Checking packet name...");
				if (forwardingTable.get(((UpdateTable)content).getNameContainer()) == null)
				{
					forwardingTable.put(cslaptopAddress, ((UpdateTable)content).getNameContainer());
					System.out.println("Added: " + cslaptopAddress + ", " + forwardingTable.get(cslaptopAddress));
				}
			}

			else if(content.getType()==PacketContent.PACKET_MESSAGE)
			{
				if (forwardingTable.get(((PacketMessage)content).getContent()) == null)
				{
					System.out.println("Sending packet with unknown next hop but with destination to controller");
					PacketMessage packetForcontroller = new PacketMessage("dserver", "hello");
					DatagramPacket packetTocontroller = packetForcontroller.toDatagramPacket();
					packetTocontroller.setSocketAddress(dstcontrollerAddress);
					socket.send(packetTocontroller);

				}
			}

			else if (content.getType()==PacketContent.CONTROLLER_FORWARDER3)
			{
				System.out.println("Adding new container to forwarding table");
				System.out.println("Checking packet name...");
				if (forwardingTable.get(((ControllerToForwarder3)content).getName()) == null)
				{
					forwardingTable.put(packetDestinationAddress, ((ControllerToForwarder3)content).getName());
					System.out.println("Added: " + packetDestinationAddress + ", " + forwardingTable.get(packetDestinationAddress));

					Forwarder3ToForwarder2 packetForforwarder2;
					packetForforwarder2 = new Forwarder3ToForwarder2(packetDestinationAddress, "hello");
					System.out.println("Sending packet to next hop: " + forwarder2Address);
					dstforwarder2Address = new InetSocketAddress(forwarder2Address, 54321);
					DatagramPacket packetSentToforwarder2 = packetForforwarder2.toDatagramPacket();
					packetSentToforwarder2.setSocketAddress(dstforwarder2Address);
					socket.send(packetSentToforwarder2);
				}
			}
		}
		catch(Exception e) {e.printStackTrace();}
	}

	public synchronized void start() throws Exception {
		System.out.println("Waiting for contact");
		this.wait();

	}

	public static void main(String[] args) {
		try {
			(new forwarder3( DEFAULT_SRC_PORT)).start();
			System.out.println("Program completed");
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
}
