/**
	 * author: Dishant Tekwani
 */
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ControllerToForwarder3 extends PacketContent {

    String name;
    String content;


    ControllerToForwarder3(String name, String content) {
        type= CONTROLLER_FORWARDER3;
        this.name = name;
        this.content = content;
        //this.dstNode = dstNode;
    }

    protected ControllerToForwarder3(ObjectInputStream oin) {
        try {
            type= CONTROLLER_FORWARDER3;
            //dstNode= oin.readUTF();
            name= oin.readUTF();
            content=oin.readUTF();
        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            //oout.writeUTF(dstNode);
            oout.writeUTF(name);
            oout.writeUTF(content);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "Content:" + content;
    }

    public String getContent()
    {
        return "Content:" + name;
    }

    public String getName() {return "Name:" + name; }

    public String getPacketInfo() {
        return content;
    }
}
