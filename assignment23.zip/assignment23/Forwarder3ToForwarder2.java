import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Forwarder3ToForwarder2 extends PacketContent {

    String name;
    String content;

    Forwarder3ToForwarder2(String name, String content) {
        type= FWD3_TO_FWD2;
        this.name = name;
        this.content = content;
        //this.dstNode = dstNode;
    }

    protected Forwarder3ToForwarder2(ObjectInputStream oin) {
        try {
            type= FWD3_TO_FWD2;
            //dstNode= oin.readUTF();
            name= oin.readUTF();
            content=oin.readUTF();
        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            //oout.writeUTF(dstNode);
            oout.writeUTF(name);
            oout.writeUTF(content);
        }
        catch(Exception e) {e.printStackTrace();}
    }


    public String toString() {
        return "Content:" + content;
    }

    public String getContent()
    {
        return "Content:" + name;
    }

    public String getName() {return "Name:" + name; }

    public String getPacketInfo() {
        return content;
    }
}
