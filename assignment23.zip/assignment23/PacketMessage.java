/**
	 * author: Dishant Tekwani
 */
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PacketMessage extends PacketContent {

    String name;
    String content;

    PacketMessage(String name, String content) {
        type= PACKET_MESSAGE;
        this.name = name;
        this.content = content;
    }

    protected PacketMessage(ObjectInputStream oin) {
        try {
            type= PACKET_MESSAGE;
            //dstNode= oin.readUTF();
            name= oin.readUTF();
            content=oin.readUTF();
        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            //oout.writeUTF(dstNode);
            oout.writeUTF(name);
            oout.writeUTF(content);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "Content:" + content;
    }

    public String getContent()
    {
        return "Content:" + name;
    }

    public String getName() {return "Name:" + name; }

    public String getPacketInfo() {
        return content;
    }
}
