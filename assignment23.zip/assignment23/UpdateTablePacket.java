/**
	 * author: Dishant Tekwani
 */
import java.util.ArrayList;

public class UpdateTablePacket {
    int port;
    String containerName;
    String lastHop;

    ArrayList packetHeaderInfo = new ArrayList();

    UpdateTablePacket(int port, String containerName, String lastHop)
    {
        this.port = port;
        this.containerName = containerName;
        this.lastHop = lastHop;

    }

    public int getPort()
    {
        return port;
    }

    public String getContainerName()
    {
        return containerName;
    }

    public String getLastHop()
    {
        return lastHop;
    }
}
