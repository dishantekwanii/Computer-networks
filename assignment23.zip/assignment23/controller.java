/**
	 * author: Dishant Tekwani
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class controller extends Node {
    static final int DEFAULT_SRC_PORT = 54321;
    InetSocketAddress dstforwarder3Address;

    String dserverAddress = "dserver";
    String forwardern3Address = "forwardern3";
    String forwardern2Address = "forwardern2";

    String[][] layoutTable = { {"dserver", "cslaptopn1", "forwardern3", "cslaptopn1", "forwardern2"},
            {"cslaptopn1", "dserver", "forwardern2", "dserver", "forwardern3"} };

    HashMap<String, String> forwardingTable;

    controller(int srccontrollerPort) {
        try {
            socket= new DatagramSocket(srccontrollerPort);
            listener.go();

            forwardingTable = new HashMap<String, String>();
        }
        catch(java.lang.Exception e) {e.printStackTrace();}
    }

    public void onReceipt(DatagramPacket packet) {
        try {

            System.out.println("Received packet");


            PacketContent content= PacketContent.fromDatagramPacket(packet);

            if(content.getType()==PacketContent.FWD_TO_CONTROLLER)
            {

                System.out.println("Controller online...");
                if (forwardingTable.get(((ForwarderToController)content).getNameContainer()) == null)
                {

                    System.out.println("Scanning packet for forwardern3 node...");
                    forwardingTable.put(forwardern3Address, ((ForwarderToController)content).getNameContainer());
                    System.out.println("Added: " + forwardern3Address + ", " + forwardingTable.get(forwardern3Address));

                    String containerOfforwarder3Node = forwardingTable.get(forwardern3Address);
                    System.out.println("Forwarder 3 address: " + containerOfforwarder3Node);
                }
            }

            else if(content.getType()==PacketContent.FWD2_TO_CONTROLLER)
            {
                if (forwardingTable.get(((Forwarder2ToController)content).getNameContainer()) == null)
                {
                    System.out.println("Scanning packet for forwardern2 node...");
                    forwardingTable.put(forwardern2Address, ((Forwarder2ToController)content).getNameContainer());
                    System.out.println("Added: " + forwardern2Address + ", " + forwardingTable.get(forwardern2Address));


                    String forwarder2Node = forwardingTable.get(forwardern2Address);
                    System.out.println("Forwarder 2 address: " + forwarder2Node);
                }
            }

            else if(content.getType()==PacketContent.PACKET_MESSAGE)
            {
                if (forwardingTable.get(((PacketMessage)content).getName()) == null)
                {
                    System.out.println("Scanning packet for destination node...");
                    forwardingTable.put(dserverAddress, ((PacketMessage)content).getName());
                    System.out.println("Added: " + dserverAddress + ", " + forwardingTable.get(dserverAddress));


                    ControllerToForwarder3 packetForforwarder3 = new ControllerToForwarder3("dserver", "hello");
                    DatagramPacket packetToforwarder3 = packetForforwarder3.toDatagramPacket();

                    String containerOfforwarder3Node = forwardingTable.get(forwardern3Address);
                    System.out.println("Sending packet to next hop: " + containerOfforwarder3Node);
                    dstforwarder3Address = new InetSocketAddress(containerOfforwarder3Node, 54321);
                    packetToforwarder3.setSocketAddress(dstforwarder3Address);
                    socket.send(packetToforwarder3);

                }
            }



        }
        catch(Exception e) {e.printStackTrace();}
    }


    private void printLayout() {
        String format = "%-7s %3s %-3s %3s %-7s %3s %-3s %3s %-3s %n";

        System.out.printf(format, "DEST", "|", "SRC", "|", "FORWARDER", "|", "BEFORE-FORWARDER", "|", "AFTER-FORWARDER");
        for(int i = 0; i < layoutTable.length; i++) {
            System.out.printf(format, layoutTable[i][DEST_ADDR], "|", layoutTable[i][SRC_ADDRESS], "|", layoutTable[i][ROUTER],
                    "|", layoutTable[i][ROUTER_BEFORE], "|", layoutTable[i][ROUTER_AFTER]);
        }
    }

    public synchronized void start() throws Exception {
        System.out.println("The layout of the network is: ");
        printLayout();

        this.wait();


    }

    /*
     *
     */
    public static void main(String[] args) {
        try {
            (new controller(DEFAULT_SRC_PORT)).start();
            System.out.println("Program completed");
        } catch(java.lang.Exception e) {e.printStackTrace();}
    }
}
