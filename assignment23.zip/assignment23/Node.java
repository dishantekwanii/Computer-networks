/**
	 * author: Dishant Tekwani
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.concurrent.CountDownLatch;
public abstract class Node {
	static final int PACKETSIZE = 65536;

	static final int DEST = 0;
	 static final int IN = 1;
	 static final int OUT = 2;

	protected static final int DEST_ADDR = 0;
	protected static final int SRC_ADDRESS = 1;
	protected static final int ROUTER = 2;
	protected static final int ROUTER_BEFORE = 3;
	protected static final int ROUTER_AFTER = 4;

	protected static final int PACKET_TYPE = 0;
	protected static final int LENGTH = 1;

	static final byte PACKET_HELLO = 0;

	DatagramSocket socket;
	Listener listener;
	CountDownLatch latch;

	Node() {
		latch= new CountDownLatch(1);
		listener= new Listener();
		listener.setDaemon(true);
		listener.start();
	}


	public abstract void onReceipt(DatagramPacket packet);

	class Listener extends Thread {

		public void go() {
			latch.countDown();
		}

		public void run() {
			try {
				latch.await();
				while(true) {
					DatagramPacket packet = new DatagramPacket(new byte[PACKETSIZE], PACKETSIZE);
					socket.receive(packet);

					onReceipt(packet);
				}
			} catch (Exception e) {if (!(e instanceof SocketException)) e.printStackTrace();}
		}
	}
}
