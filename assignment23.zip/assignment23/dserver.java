/**
	 * author: Dishant Tekwani
 */
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

public class dserver extends Node {
    static final int DEFAULT_PORT = 54321;
    InetSocketAddress dstAddress;

    dserver(int port) {
        try {
            socket= new DatagramSocket(port);
            listener.go();
        }
        catch(java.lang.Exception e) {e.printStackTrace();}
    }

    public void onReceipt(DatagramPacket packet) {
        //byte[] data = packet.getData();
        System.out.println("Received packet with message...");
        PacketContent content= PacketContent.fromDatagramPacket(packet);

        if (content.getType()==PacketContent.FWD2_TO_DEST)
        {
            String prevHop = packet.getAddress().getHostName();
            System.out.println("Received packet from previous hop on the network: " + prevHop);

        }
    }


    public synchronized void start() throws Exception {
        System.out.println("Waiting for contact");
        this.wait();
    }


    public static void main(String[] args) {
        try {
            (new dserver(DEFAULT_PORT)).start();
            System.out.println("Program completed");
        } catch(java.lang.Exception e) {e.printStackTrace();}
    }
}
