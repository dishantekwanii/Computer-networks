import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;

public class Forwarder2ToController extends PacketContent {

    String nameContainer;

    Forwarder2ToController(String nameContainer) {
        type= FWD2_TO_CONTROLLER;
        this.nameContainer = nameContainer;

    }

    protected Forwarder2ToController(ObjectInputStream oin) {
        try {
            type= FWD2_TO_CONTROLLER;
            nameContainer= oin.readUTF();

        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            oout.writeUTF(nameContainer);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "ContainerName: " + nameContainer;
    }

    public String getNameContainer()
    {
        return nameContainer;
    }



}
