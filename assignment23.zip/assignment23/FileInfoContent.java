/**
	 * author: Dishant Tekwani
 */
import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileInfoContent extends PacketContent {

	String filename;
	int size;

	FileInfoContent(String filename, int size) {
		type= FILEINFO;
		this.filename = filename;
		this.size= size;
	}

	protected FileInfoContent(ObjectInputStream oin) {
		try {
			type= FILEINFO;
			filename= oin.readUTF();
			size= oin.readInt();
		}
		catch(Exception e) {e.printStackTrace();}
	}

	protected void toObjectOutputStream(ObjectOutputStream oout) {
		try {
			oout.writeUTF(filename);
			oout.writeInt(size);
		}
		catch(Exception e) {e.printStackTrace();}
	}

	public String toString() {
		return "Filename: " + filename + " - Size: " + size;
	}

	public String getFileName() {
		return filename;
	}

	public int getFileSize() {
		return size;
	}
}
