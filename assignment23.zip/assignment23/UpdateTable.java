/**
	 * author: Dishant Tekwani
 */
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;

public class UpdateTable extends PacketContent {

    String nameContainer;


    UpdateTable(String nameContainer) {
        type= TO_UPDATE_TABLE;
        this.nameContainer = nameContainer;

    }

    protected UpdateTable(ObjectInputStream oin) {
        try {
            type= TO_UPDATE_TABLE;
            nameContainer= oin.readUTF();

        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            oout.writeUTF(nameContainer);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "ContainerName: " + nameContainer;
    }

    public String getNameContainer()
    {
        return nameContainer;
    }
}
