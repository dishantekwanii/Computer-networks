/**
	 * author: Dishant Tekwani
 */
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;

public class NoUpdateTable extends PacketContent {

    String filename;
    int size;
    InetSocketAddress packetAddress;

    NoUpdateTable(String filename, int size, InetSocketAddress packetAddress) {
        //type= NO_UPDATE_TABLE;
        this.filename = filename;
        this.size= size;
        this.packetAddress = packetAddress;
    }

    protected NoUpdateTable(ObjectInputStream oin) {
        try {
            //type= NO_UPDATE_TABLE;
            filename= oin.readUTF();
            size= oin.readInt();
        }
        catch(Exception e) {e.printStackTrace();}
    }

    protected void toObjectOutputStream(ObjectOutputStream oout) {
        try {
            oout.writeUTF(filename);
            oout.writeInt(size);
        }
        catch(Exception e) {e.printStackTrace();}
    }

    public String toString() {
        return "Filename: " + filename + " - Size: " + size;
    }


    public InetSocketAddress getPacketAddress()
    {
        return packetAddress;
    }
}
