/**
	 * author: Dishant Tekwani
 */
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

public class cslaptop extends Node {
	static final int DEFAULT_SRC_PORT = 54321;
	static final int DEFAULT_DST_PORT = 54321;
	static final String DEFAULT_DST_NODE = "192.168.17.3";
	InetSocketAddress dstAddress;
	InetSocketAddress dstforwarder3Address;

	cslaptop(String dstHost, int dstPort, int srcPort) {
		try {
			dstAddress= new InetSocketAddress(dstHost, dstPort);
			dstforwarder3Address = new InetSocketAddress("forwardern3", 54321);

			socket= new DatagramSocket(srcPort);
			listener.go();
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	public synchronized void onReceipt(DatagramPacket packet) {
		System.out.println("Received packet along with message: ");
	}


	public synchronized void start() throws Exception {

		UpdateTable updateFwdTable = new UpdateTable("cslaptopn1");
		DatagramPacket UpdateTablePacket = updateFwdTable.toDatagramPacket();
		UpdateTablePacket.setSocketAddress(dstforwarder3Address);
		socket.send(UpdateTablePacket);


		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the destination for packet: ");
		String destination = scanner.nextLine();
		System.out.println("Enter the message for packet: ");
		String message = scanner.nextLine();

		PacketMessage messagePacket = new PacketMessage(message, destination );

		DatagramPacket packetWithMessage = messagePacket.toDatagramPacket();
		packetWithMessage.setSocketAddress(dstforwarder3Address);
		socket.send(packetWithMessage);

		this.wait();
		scanner.close();
	}


	public static void main(String[] args) {
		try {
			(new cslaptop(DEFAULT_DST_NODE, DEFAULT_DST_PORT, DEFAULT_SRC_PORT)).start();
			System.out.println("Program completed");
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
}
