/**
	 * author: Dishant Tekwani
 */
import java.io.*;
import java.net.DatagramPacket;

public abstract class PacketContent {

	public static final int ACKPACKET= 10;
	public static final int FILEINFO= 100;
	public static final int CONTROLLER_FORWARDER3 = 250;
	public static final int FWD3_TO_FWD2 = 700;
	public static final int FWD2_TO_CONTROLLER = 300;
	public static final int TO_UPDATE_TABLE = 400;
	public static final int PACKET_MESSAGE = 500;
	public static final int FWD_TO_CONTROLLER = 600;
	public static final int FWD2_TO_DEST = 800;

	int type= 0;

	public static PacketContent fromDatagramPacket(DatagramPacket packet) {
		PacketContent content= null;

		try {
			int type;

			byte[] data;
			ByteArrayInputStream bin;
			ObjectInputStream oin;

			data= packet.getData();
			bin= new ByteArrayInputStream(data);
			oin= new ObjectInputStream(bin);

			type= oin.readInt();

			switch(type) {
			case FILEINFO:
				content= new FileInfoContent(oin);
				break;
			case PACKET_MESSAGE:
				content= new PacketMessage(oin);
				break;
			case FWD3_TO_FWD2:
				content= new Forwarder3ToForwarder2(oin);
				break;
				case FWD2_TO_DEST:
				content= new Forwarder2ToDserver(oin);
				break;
			case FWD_TO_CONTROLLER:
				content= new ForwarderToController(oin);
				break;
			case TO_UPDATE_TABLE:
				content= new UpdateTable(oin);
				break;
			case CONTROLLER_FORWARDER3:
				content= new ControllerToForwarder3(oin);
				break;
			default:
				content= null;
				break;
			}
			oin.close();
			bin.close();

		}
		catch(Exception e) {e.printStackTrace();}

		return content;
	}

	protected abstract void toObjectOutputStream(ObjectOutputStream out);

	public DatagramPacket toDatagramPacket() {
		DatagramPacket packet= null;

		try {
			ByteArrayOutputStream bout;
			ObjectOutputStream oout;
			byte[] data;

			bout= new ByteArrayOutputStream();
			oout= new ObjectOutputStream(bout);

			oout.writeInt(type);
			toObjectOutputStream(oout);

			oout.flush();
			data= bout.toByteArray();

			packet= new DatagramPacket(data, data.length);
			oout.close();
			bout.close();
		}
		catch(Exception e) {e.printStackTrace();}

		return packet;
	}


	public abstract String toString();

	public int getType() {
		return type;
	}


}
